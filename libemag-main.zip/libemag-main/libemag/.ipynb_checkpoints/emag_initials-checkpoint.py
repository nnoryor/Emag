from scipy.constants import pi, epsilon_0, c, mu_0
from scipy.linalg import norm
from scipy.integrate import quad
from numpy import sqrt