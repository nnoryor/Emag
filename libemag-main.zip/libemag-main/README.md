# libemag
Library for Electromagnetic Fields for Engineering
